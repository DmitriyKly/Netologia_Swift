import UIKit

//Task 1

enum Channel: String {
    
    case first = "1 канал"
    case second = "2 Канал"
    case third = "3 Канал"
    
}

class TV {
    
    var model: String
    var status: Bool
    var currentChannel: String
    init (model: String, status: Bool, currentChannel: String)  {
        self.model = model
        self.status = status
        self.currentChannel = currentChannel
    }
    
    func showCurrentChannel() {
        if status {
            print("Телек \(model) показывает \(currentChannel) ")  }
        else
            { print("Включи ящик") }
            
        }
    
    }

var television = TV(model: "Samsung", status: true, currentChannel: Channel.first.rawValue)

television.showCurrentChannel()
 
// Сделайте изменение состояния телевизора ( на свой выбор )

var television2 = TV(model: "LG", status: false, currentChannel: Channel.second.rawValue)

television2.showCurrentChannel()


//Task 2

struct NewFeature {
    
    var volume: Double
    var color: Bool
    
}

class New_TV: TV {
    
    var volume: Double = 0
    var newFeature: NewFeature {
        willSet {
            if newValue.volume > 1.0 {
                volume = 1.0
            }
            else if newValue.volume < 0 {
                volume = 0
            }
            else {
                volume = newValue.volume
            }
        }
    }
    
    init (model: String, status: Bool, currentChannel: String, newFeature: NewFeature) {
        self.newFeature = newFeature
        super.init(model: model, status: status, currentChannel: currentChannel)
    }
    
    
    override func showCurrentChannel() {
        if status {
            
            print("Телек \(model) показывает \(currentChannel) с громкостью \(volume)")
            
            if newFeature.color {
                print("Включен цветной режим")
            }
            else { print("Включен Ч/Б") }
            
        }
        
        else   {
            print("Включи ящик")
            
        }
        
    }
}


var television3 = New_TV(model: "Panasonic", status: true, currentChannel: Channel.first.rawValue, newFeature: NewFeature.init(volume: 0.0, color: true))



television3.showCurrentChannel()
television3.newFeature.volume = 0.5
television3.showCurrentChannel()
television3.newFeature.volume = -4
television3.showCurrentChannel()
television3.newFeature.volume = 4
television3.showCurrentChannel()

