//
//  ProfileView.swift
//  Netology_IB_Instruments
//
//  Created by dmitriy on 13/5/2023.
//

import UIKit

    class ProfileView: UIView {
        
        @IBOutlet weak var image: UIImageView!
        
        @IBOutlet weak var userName: UILabel!
        
        @IBOutlet weak var dateOfBirth: UILabel!
        
        @IBOutlet weak var city: UILabel!
        
        @IBOutlet weak var text: UITextView!
    }

